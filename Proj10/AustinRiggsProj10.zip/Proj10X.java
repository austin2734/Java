// Asg10
// Austin Riggs
// 04/18/23
// ITSE-2321-001

// definition of interface Proj10X
interface Proj10X
{
	public int getModifiedData();
	public int getData();
	
} // end of Proj10X