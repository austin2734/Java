/* File Proj12Skeleton.txt
Student must rename this file from Proj12Skeleton.txt
to Proj12Runner.java. Then student must update this 
file to cause the program to meet the assignment 
specifications by:
1. Inserting his or her name where indicated.
2. Modifying ONLY ONE other physical line of code.
DO NOT add any new lines of code.
*****************************************************/

class Proj12Runner{

  String var = "";

  //================================================//
  Proj12Runner(String val){
    var = val;
    System.out.print("My name is \n" +
      "Austin Riggs" +
      "\nand ");
  }// end constructor
  //================================================//
  
  String run(String var){
    return this.var;
  }//end run method
  
}//end class Proj12Runner