// Asg07
// Austin Riggs
// 03/29/23
// ITSE-2321-001

// Creation of the Proj07Runner class that extends the Proj07 class 
class Proj07Runner extends Proj07  
{
	// Proj07 constructor
	public Proj07Runner()
	{
		System.out.println(
		  "\n I certify that this program is my own work \n" +
          "and is not the work of others. I agree not \n" +
          "to share my solution with others.\n");
	}
	
    // Overrides Proj07 run method	
	void run()
	{
		System.out.println("Austin Riggs \n");
		
	} // end run 
} // end class Proj07Runner